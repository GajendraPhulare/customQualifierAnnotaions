package CustomQualifierAnnotations.CustomQualifierAnnotations;



public interface CompactDisc {
void play();
}
