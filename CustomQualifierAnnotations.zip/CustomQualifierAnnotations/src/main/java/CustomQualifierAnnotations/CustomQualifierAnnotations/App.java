package CustomQualifierAnnotations.CustomQualifierAnnotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class App 
{
	static private CDPlayer cdPlayer;
    public static void main( String[] args )
    {

    	ApplicationContext context2=new AnnotationConfigApplicationContext(CompConfig.class);
    	
    	cdPlayer= context2.getBean(CDPlayer.class);
       cdPlayer.startPlayer();
    }
}
