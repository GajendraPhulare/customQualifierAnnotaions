package CustomQualifierAnnotations.CustomQualifierAnnotations;

import org.springframework.stereotype.Component;

@Component
@New
public class NewSongsDC implements CompactDisc {

	
	public void play() {
		
	System.out.println(" Playing new song 1.......");	
	}

	

	

}
