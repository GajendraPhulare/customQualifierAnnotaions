package CustomQualifierAnnotations.CustomQualifierAnnotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class SonyPlayer implements CDPlayer{
	
	
	CompactDisc cd;
	
	SonyPlayer(@New CompactDisc cd){
		this.cd=cd;
	}

	
	public void startPlayer() {
		System.out.println("Player Started...");
		cd.play();
	}

	

}
