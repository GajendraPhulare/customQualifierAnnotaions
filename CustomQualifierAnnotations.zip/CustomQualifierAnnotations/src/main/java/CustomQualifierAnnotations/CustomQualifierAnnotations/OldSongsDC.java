package CustomQualifierAnnotations.CustomQualifierAnnotations;

import org.springframework.stereotype.Component;

@Component
public class OldSongsDC implements CompactDisc {

	
	public void play() {
		
	System.out.println(" Playing old song 1.......");	
	}

	

	

}
